create definer = root@localhost trigger t_in
    after insert
    on user
    for each row
begin
    if new.type like 'teacher' then
        if new.uid not in (select uid from stu_qa.teacher) then
            insert into stu_qa.teacher(uid) values (new.uid);
        end if;
    end if;
end;

