create definer = root@localhost trigger t_out
    after delete
    on user
    for each row
begin
    if old.type like 'teacher' then
        delete from stu_qa.teacher where uid = old.uid;
    end if;
end;

