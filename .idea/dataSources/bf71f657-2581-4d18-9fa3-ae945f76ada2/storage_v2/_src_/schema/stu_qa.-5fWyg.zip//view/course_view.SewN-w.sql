create definer = root@localhost view course_view as
select `stu_qa`.`course`.`cid`       AS `cid`,
       `stu_qa`.`course`.`cname`     AS `cname`,
       `stu_qa`.`course`.`describe`  AS `describe`,
       `stu_qa`.`course`.`score`     AS `score`,
       `stu_qa`.`course`.`uid`       AS `uid`,
       `stu_qa`.`course`.`forbidden` AS `forbidden`,
       `stu_qa`.`user`.`name`        AS `tname`
from (`stu_qa`.`course` left join `stu_qa`.`user` on ((`stu_qa`.`user`.`uid` = `stu_qa`.`course`.`uid`)));

