create definer = root@localhost view uc as
select `stu_qa`.`sc`.`uid` AS `uid`, `stu_qa`.`sc`.`cid` AS `cid`
from `stu_qa`.`sc`
union
select `stu_qa`.`course`.`uid` AS `uid`, `stu_qa`.`course`.`cid` AS `cid`
from `stu_qa`.`course`;

