create definer = root@localhost view question_head_view as
select `stu_qa`.`questionhead`.`qid`     AS `qid`,
       `stu_qa`.`questionhead`.`stuUid`  AS `stuUid`,
       `stu_qa`.`questionhead`.`cid`     AS `cid`,
       `stu_qa`.`questionhead`.`title`   AS `title`,
       `stu_qa`.`questionhead`.`pub`     AS `pub`,
       `stu_qa`.`questionhead`.`stuRead` AS `stuRead`,
       `stu_qa`.`questionhead`.`teaRead` AS `teaRead`,
       `stu_qa`.`questionhead`.`teaAns`  AS `teaAns`,
       `stu_qa`.`questionhead`.`time`    AS `time`,
       `stu_qa`.`c`.`cname`              AS `cname`,
       `stu_qa`.`c`.`tname`              AS `tname`,
       `stu_qa`.`c`.`uid`                AS `teaUid`,
       `stu_qa`.`c`.`forbidden`          AS `forbidden`
from (`stu_qa`.`questionhead` left join `stu_qa`.`course_view` `c`
      on ((`stu_qa`.`questionhead`.`cid` = `stu_qa`.`c`.`cid`)));

